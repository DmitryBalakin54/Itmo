print("task solved")
