print('task solved')
